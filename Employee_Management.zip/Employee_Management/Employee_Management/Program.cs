﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee_Management
{
    public class Program
    {
        static void Main(string[] args)
        {
        
            startconsole:

            Console.WriteLine("***Welcome to Employee Management***");

            Console.Write("Enter your option : ");
            Console.WriteLine("1. Add Employee (Employee Name, No, Phone no, City, Years of Experience");
            Console.WriteLine("2.Edit Employee");
            Console.WriteLine("3.Search for Employee");
            Console.WriteLine("4.Show all Employees");
            Console.WriteLine("5.Delete Employee");
            Console.WriteLine("6.Exit Program");

            Console.Write("Select any option ");

            int option = Convert.ToInt16(Console.ReadLine());

            if (option == 1)
            {
                Console.Write("Enter Employee Name : ");
                string Name = Console.ReadLine();

                Console.Write("Enter Employee No :");
                string EmpNo = Console.ReadLine();

                Console.Write("Enter Employee Phone Number :");
                string EmpPhone = Console.ReadLine();

                Console.Write("Enter Employee City : ");
                string EmpCity = Console.ReadLine();

                Console.Write("Enter Employee Year of Experiance : ");
                string EmpExp = Console.ReadLine();

                Console.WriteLine("Employee Detail Inserted Successfully");            

            }
            Console.WriteLine("Do you want to repeat the option Y / N ?");
            string optionresult = Console.ReadLine();
            if (optionresult == "Y")
            {
                goto startconsole;
            }


            Console.WriteLine("Pascal Pyramid program");

            for (int i = 0; i <= 5; ++i)
            {
                for (int j = 1; j <= i; ++j)
                {
                    Console.Write("{0}  {1}", i, j);
                }
                Console.WriteLine();
            }

        }   
    }
}
